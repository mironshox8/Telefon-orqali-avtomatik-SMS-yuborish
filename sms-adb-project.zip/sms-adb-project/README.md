# SMS Gateway — ADB orqali SMS yuborish

PHP veb interfeysi orqali Android telefonni masofadan boshqarish va SMS yuborish loyihasi. ADB over WiFi texnologiyasi ishlatilgan.

## 📋 Tuzilishi

```
sms-adb-project/
├── public/
│   ├── index.php       # Asosiy veb interfeys
│   └── api.php         # API endpoint
├── includes/
│   ├── config.php      # Konfiguratsiya
│   └── AdbSms.php      # Asosiy klass
└── logs/
    └── sms.log         # Yuborilgan SMS loglari
```

## 🛠 Talablar

### Kompyuterda:
- **PHP 7.4+** (`exec()` funksiyasi yoqilgan bo'lishi kerak)
- **ADB (Android Debug Bridge)** — [bu yerdan yuklab oling](https://developer.android.com/tools/releases/platform-tools)
- Veb server (Apache, Nginx yoki PHP built-in)

### Telefonda:
- **Android 11+** (yangiroq versiyalar uchun)
- **Developer options** yoqilgan
- **Wireless debugging** yoqilgan
- Kompyuter va telefon **bitta WiFi tarmog'ida**

## 📱 Telefonni tayyorlash

### 1-qadam: Developer options yoqish
1. **Settings → About phone** ga kiring
2. **Build number** ustiga 7 marta bosing
3. "You are now a developer" yozuvini ko'rasiz

### 2-qadam: Wireless debugging yoqish

**Android 11+ uchun:**
1. **Settings → System → Developer options**
2. **Wireless debugging** ni yoqing
3. **Pair device with pairing code** ni tanlang
4. Pairing code, IP va portni ko'rasiz

**Eski Androidlar uchun (Root kerak yoki USB orqali):**
```bash
# USB kabel orqali ulanib:
adb tcpip 5555
# Endi kabelni uzib, WiFi orqali ulanish mumkin
```

### 3-qadam: IP manzilni topish
**Settings → About phone → Status → IP address**

Masalan: `192.168.1.100`

## 💻 Kompyuterda o'rnatish

### ADB ni o'rnatish

**Ubuntu/Debian:**
```bash
sudo apt install adb
```

**Mac (Homebrew):**
```bash
brew install android-platform-tools
```

**Windows:**
1. [Platform-tools](https://developer.android.com/tools/releases/platform-tools) ni yuklab oling
2. `C:\platform-tools` ga ko'chiring
3. PATH muhit o'zgaruvchisiga qo'shing

ADB ishlayotganini tekshiring:
```bash
adb version
```

### Loyihani o'rnatish

```bash
# 1. Loyihani serverga ko'chiring
# 2. Konfiguratsiyani sozlang:
nano includes/config.php
```

`config.php` da quyidagilarni o'zgartiring:
```php
'phone_ip'        => '192.168.1.100',  // Telefoningiz IP si
'phone_port'      => 5555,              // ADB porti
'adb_path'        => '/usr/bin/adb',    // ADB yo'li
'access_password' => 'mahkam_parol',    // Veb interfeys paroli
```

### Test qilish

```bash
# PHP built-in server bilan ishga tushirish:
cd public
php -S localhost:8000

# Brauzerda oching: http://localhost:8000
```

## 🔌 Birinchi ulanish (Pairing)

Android 11+ da har bir kompyuter telefonga bir marta "pair" qilinishi kerak:

```bash
# 1. Telefonda "Pair device with pairing code" ni tanlang
# 2. Pairing code, IP va portni ko'rasiz, masalan:
#    IP: 192.168.1.100:41234
#    Code: 123456

# 3. Terminalda:
adb pair 192.168.1.100:41234
# Pairing code ni kiriting: 123456

# 4. Endi doimiy ulanish portiga ulaning (5555):
adb connect 192.168.1.100:5555
```

Faqat **birinchi marta** pair qilish kerak. Keyingi safar to'g'ridan-to'g'ri veb interfeysdan ulanish mumkin.

## 🚀 Foydalanish

1. Brauzerda `http://localhost:8000` ni oching
2. Parol kiriting (config.php dagi `access_password`)
3. **"Ulanish"** tugmasini bosing
4. Telefon raqami va xabar matnini kiriting
5. **"SMS Yuborish"** ni bosing

### Ommaviy SMS yuborish

**"Ommaviy"** tabini tanlang va raqamlarni quyidagicha kiriting:
```
+998901234567
+998907654321
+998935554433
```

yoki vergul bilan:
```
+998901234567, +998907654321, +998935554433
```

## ⚙️ Qanday ishlaydi?

SMS yuborish ikki bosqichda amalga oshiriladi:

1. **Intent yuborish** — Android SMS ilovasini ochish, raqam va matnni avtomatik to'ldirish:
   ```bash
   adb shell am start -a android.intent.action.SENDTO \
       -d sms:+998901234567 \
       --es sms_body "Salom" \
       --ez exit_on_sent true
   ```

2. **"Yuborish" tugmasini bosish** — key event lar orqali:
   ```bash
   adb shell input keyevent 22   # DPAD_RIGHT
   adb shell input keyevent 66   # ENTER
   ```

## ⚠️ Muhim ogohlantirishlar

### Xavfsizlik
- **`access_password`** ni majburiy o'zgartiring
- Loyihani **internetga ochmang** — faqat lokal tarmoqda ishlating
- `logs/` papkasini veb dan yashirin qiling (`.htaccess` yoki Nginx config)

### Telefon ekrani
- Telefon ekrani **qulflanmagan** bo'lishi kerak (yoki Wake Lock ishlatish)
- SIM karta bo'lishi shart
- SMS yuborish balansga ta'sir qiladi

### Tugma koordinatalari
Turli telefonlarda "Yuborish" tugmasining holati farq qiladi. Agar SMS avtomatik yuborilmayotgan bo'lsa, `AdbSms.php` faylida `sendSms()` metodida `keyevent` qiymatlarini moslang yoki **tap koordinatasi** ishlating:

```php
// Misol: Send tugmasi (1000, 1850) koordinatasida bo'lsa:
$this->exec("$adb shell input tap 1000 1850");
```

Ekran koordinatalarini topish uchun:
```bash
adb shell getevent -lt
# Yoki: Settings → Developer options → "Pointer location"
```

## 🐛 Muammolarni hal qilish

### "adb: command not found"
ADB ni o'rnatib, PATH ga qo'shing yoki `config.php` da to'liq yo'lni ko'rsating:
```php
'adb_path' => '/usr/local/bin/adb',  // yoki: 'C:\\platform-tools\\adb.exe'
```

### "unauthorized" status
Telefonda **"Always allow from this computer"** ni belgilab, **OK** ni bosing.

### "connection refused"
- Telefon va kompyuter bir tarmoqdami?
- Wireless debugging yoqilganmi?
- Telefon uxlamaganmi? Ekranni yoqing
- Router AP isolation ni o'chiring

### SMS yuborilmayapti
- SIM karta bormi?
- Default SMS ilovasi sifatida "Messages" o'rnatilganmi?
- Tugma koordinatalarini moslang (yuqorida)
- Web shellda test qiling:
  ```bash
  adb shell am start -a android.intent.action.SENDTO -d sms:+998901234567 --es sms_body "test"
  ```

### PHP `exec()` o'chirilgan
`php.ini` da:
```ini
disable_functions =    ; Ro'yxatdan "exec" ni olib tashlang
```

## 📝 cURL orqali API ishlatish

Boshqa dasturlardan ham foydalanish mumkin:

```bash
# Login
curl -c cookies.txt -d "action=login&password=mahkam_parol" \
     http://localhost:8000/api.php

# SMS yuborish
curl -b cookies.txt \
     -d "action=send&phone=+998901234567&message=Salom" \
     http://localhost:8000/api.php
```

## 📜 Litsenziya

MIT License — istalganicha foydalaning, lekin **faqat qonuniy maqsadlarda**.

---

**Diqqat:** Bu loyiha shaxsiy va o'rganish maqsadlari uchun. Spam, firibgarlik yoki boshqalar nomidan SMS yuborish — jinoiy javobgarlikka olib keladi. Mas'uliyat foydalanuvchining zimmasida.
