<?php
/**
 * SMS ADB Konfiguratsiya fayli
 * Telefon va ADB sozlamalari
 */

return [
    // Telefon IP manzili (telefon Settings > About > Status > IP address)
    'phone_ip'     => '192.168.1.100',
    
    // ADB porti (odatda 5555)
    'phone_port'   => 5555,
    
    // ADB binary fayl yo'li
    // Linux: '/usr/bin/adb' yoki 'adb'
    // Windows: 'C:\\platform-tools\\adb.exe'
    // Mac: '/usr/local/bin/adb'
    'adb_path'     => 'adb',
    
    // Log faylga yozish
    'enable_log'   => true,
    'log_file'     => __DIR__ . '/../logs/sms.log',
    
    // Xavfsizlik: oddiy parol (production uchun yaxshilang)
    'access_password' => 'change_this_password',
    
    // Bir vaqtda yuborilishi mumkin bo'lgan maksimal SMS
    'max_bulk_sms' => 50,
    
    // SMS lar orasidagi pauza (sekund)
    'sms_delay'    => 2,
];
