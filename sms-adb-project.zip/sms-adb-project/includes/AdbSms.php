<?php
/**
 * AdbSms - ADB orqali SMS yuborish klassi
 */

class AdbSms
{
    private $config;
    private $connected = false;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    /**
     * Shell komandasini xavfsiz bajarish
     */
    private function exec(string $command): array
    {
        $output = [];
        $returnCode = 0;
        exec($command . ' 2>&1', $output, $returnCode);
        
        return [
            'success' => $returnCode === 0,
            'output'  => implode("\n", $output),
            'code'    => $returnCode,
        ];
    }

    /**
     * Log yozish
     */
    private function log(string $message): void
    {
        if (empty($this->config['enable_log'])) {
            return;
        }
        
        $logDir = dirname($this->config['log_file']);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        $time = date('Y-m-d H:i:s');
        file_put_contents(
            $this->config['log_file'],
            "[$time] $message\n",
            FILE_APPEND | LOCK_EX
        );
    }

    /**
     * Telefonga ADB orqali ulanish
     */
    public function connect(): array
    {
        $adb  = escapeshellcmd($this->config['adb_path']);
        $ip   = escapeshellarg($this->config['phone_ip']);
        $port = (int) $this->config['phone_port'];
        
        $result = $this->exec("$adb connect $ip:$port");
        
        if ($result['success'] && stripos($result['output'], 'connected') !== false) {
            $this->connected = true;
            $this->log("Telefonga ulandi: {$this->config['phone_ip']}:$port");
            return ['ok' => true, 'message' => $result['output']];
        }
        
        $this->log("Ulanishda xatolik: {$result['output']}");
        return ['ok' => false, 'message' => $result['output']];
    }

    /**
     * Ulanishni uzish
     */
    public function disconnect(): array
    {
        $adb  = escapeshellcmd($this->config['adb_path']);
        $ip   = escapeshellarg($this->config['phone_ip']);
        $port = (int) $this->config['phone_port'];
        
        $result = $this->exec("$adb disconnect $ip:$port");
        $this->connected = false;
        
        return ['ok' => $result['success'], 'message' => $result['output']];
    }

    /**
     * Ulangan qurilmalar ro'yxati
     */
    public function devices(): array
    {
        $adb = escapeshellcmd($this->config['adb_path']);
        $result = $this->exec("$adb devices");
        
        $devices = [];
        $lines = explode("\n", $result['output']);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || stripos($line, 'List of devices') !== false) {
                continue;
            }
            if (preg_match('/^(\S+)\s+(device|offline|unauthorized)/', $line, $m)) {
                $devices[] = ['id' => $m[1], 'status' => $m[2]];
            }
        }
        
        return ['ok' => $result['success'], 'devices' => $devices];
    }

    /**
     * Telefon ekranini yoqish (qulflangan bo'lsa)
     */
    public function wakeUp(): void
    {
        $adb = escapeshellcmd($this->config['adb_path']);
        // KEYCODE_WAKEUP = 224
        $this->exec("$adb shell input keyevent 224");
    }

    /**
     * SMS yuborish
     * 
     * @param string $phoneNumber Telefon raqami (+998901234567)
     * @param string $message     Xabar matni
     * @return array
     */
    public function sendSms(string $phoneNumber, string $message): array
    {
        // Validatsiya
        $phoneNumber = trim($phoneNumber);
        if (!preg_match('/^\+?[0-9]{7,15}$/', $phoneNumber)) {
            return ['ok' => false, 'message' => 'Noto\'g\'ri telefon raqami formati'];
        }
        
        if (trim($message) === '') {
            return ['ok' => false, 'message' => 'Xabar bo\'sh bo\'lishi mumkin emas'];
        }

        $adb = escapeshellcmd($this->config['adb_path']);
        
        // Telefon raqamini xavfsiz qilish
        $safePhone = escapeshellarg($phoneNumber);
        
        // Xabarni xavfsiz qilish - bo'shliqlarni %s bilan almashtirish ham mumkin
        // Lekin escapeshellarg yaxshiroq
        $safeMessage = escapeshellarg($message);
        
        // SMS yuborish ikki qadamda:
        // 1. SMS ilovasini ochish va matn kiritish
        $cmd = "$adb shell am start -a android.intent.action.SENDTO "
             . "-d sms:$safePhone "
             . "--es sms_body $safeMessage "
             . "--ez exit_on_sent true";
        
        $result = $this->exec($cmd);
        
        if (!$result['success']) {
            $this->log("SMS yuborish xatosi ($phoneNumber): {$result['output']}");
            return ['ok' => false, 'message' => 'SMS ilovasini ochib bo\'lmadi: ' . $result['output']];
        }
        
        // Ilova yuklanishini kutamiz
        usleep(1500000); // 1.5 sekund
        
        // 2. "Yuborish" tugmasini bosish (KEYCODE_DPAD_RIGHT + KEYCODE_ENTER)
        // Turli telefonlarda turli xil. Eng ishonchli yo'l - tap koordinatasi
        // Yoki "Send" tugmasi key event:
        // Samsung va boshqa zamonaviy telefonlarda:
        $this->exec("$adb shell input keyevent 22"); // DPAD_RIGHT (Send tugmasiga o'tish)
        usleep(300000);
        $this->exec("$adb shell input keyevent 66"); // ENTER (yuborish)
        
        $this->log("SMS yuborildi: $phoneNumber");
        
        return [
            'ok' => true,
            'message' => "SMS $phoneNumber raqamiga yuborildi",
            'phone' => $phoneNumber,
        ];
    }

    /**
     * Bir nechta raqamga SMS yuborish
     */
    public function sendBulkSms(array $phoneNumbers, string $message): array
    {
        $results = [];
        $delay = (int) ($this->config['sms_delay'] ?? 2);
        $max = (int) ($this->config['max_bulk_sms'] ?? 50);
        
        if (count($phoneNumbers) > $max) {
            return [
                'ok' => false,
                'message' => "Maksimal $max ta raqamga yuborish mumkin",
            ];
        }
        
        foreach ($phoneNumbers as $phone) {
            $results[] = $this->sendSms($phone, $message);
            sleep($delay);
        }
        
        $success = count(array_filter($results, fn($r) => $r['ok']));
        
        return [
            'ok' => true,
            'total' => count($phoneNumbers),
            'success' => $success,
            'failed' => count($phoneNumbers) - $success,
            'details' => $results,
        ];
    }

    /**
     * Ulanish holatini tekshirish
     */
    public function isConnected(): bool
    {
        $devices = $this->devices();
        if (!$devices['ok']) return false;
        
        $expectedId = $this->config['phone_ip'] . ':' . $this->config['phone_port'];
        foreach ($devices['devices'] as $d) {
            if ($d['id'] === $expectedId && $d['status'] === 'device') {
                return true;
            }
        }
        return false;
    }
}
