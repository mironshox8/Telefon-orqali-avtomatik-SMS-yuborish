<?php
/**
 * API Endpoint - AJAX so'rovlarni qayta ishlaydi
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/AdbSms.php';
$config = require __DIR__ . '/../includes/config.php';

// Oddiy autentifikatsiya
function checkAuth($config) {
    if (!isset($_SESSION['authenticated']) || $_SESSION['authenticated'] !== true) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Avtorizatsiya talab qilinadi']);
        exit;
    }
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Login
if ($action === 'login') {
    $password = $_POST['password'] ?? '';
    if (hash_equals($config['access_password'], $password)) {
        $_SESSION['authenticated'] = true;
        echo json_encode(['ok' => true, 'message' => 'Muvaffaqiyatli kirildi']);
    } else {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Noto\'g\'ri parol']);
    }
    exit;
}

// Logout
if ($action === 'logout') {
    session_destroy();
    echo json_encode(['ok' => true]);
    exit;
}

// Boshqa har bir action uchun avtorizatsiya
checkAuth($config);

$sms = new AdbSms($config);

switch ($action) {
    case 'connect':
        echo json_encode($sms->connect());
        break;

    case 'disconnect':
        echo json_encode($sms->disconnect());
        break;

    case 'status':
        $devices = $sms->devices();
        $isConn = $sms->isConnected();
        echo json_encode([
            'ok' => true,
            'connected' => $isConn,
            'devices' => $devices['devices'] ?? [],
        ]);
        break;

    case 'send':
        $phone = $_POST['phone'] ?? '';
        $message = $_POST['message'] ?? '';
        $sms->wakeUp();
        usleep(500000);
        echo json_encode($sms->sendSms($phone, $message));
        break;

    case 'send_bulk':
        $phones = $_POST['phones'] ?? '';
        $message = $_POST['message'] ?? '';
        
        // Raqamlarni ajratish (vergul yoki yangi qator)
        $list = preg_split('/[\s,;]+/', $phones);
        $list = array_filter(array_map('trim', $list));
        
        if (empty($list)) {
            echo json_encode(['ok' => false, 'message' => 'Telefon raqamlari kiritilmadi']);
            break;
        }
        
        $sms->wakeUp();
        echo json_encode($sms->sendBulkSms(array_values($list), $message));
        break;

    case 'logs':
        $logFile = $config['log_file'];
        if (file_exists($logFile)) {
            $lines = file($logFile, FILE_IGNORE_NEW_LINES);
            $lastLines = array_slice($lines, -50);
            echo json_encode(['ok' => true, 'logs' => array_reverse($lastLines)]);
        } else {
            echo json_encode(['ok' => true, 'logs' => []]);
        }
        break;

    default:
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Noma\'lum so\'rov']);
}
