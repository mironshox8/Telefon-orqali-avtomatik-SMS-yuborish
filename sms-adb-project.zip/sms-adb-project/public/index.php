<?php session_start(); ?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMS Gateway — ADB Console</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
    :root {
        --bg: #0a0e0a;
        --bg-elevated: #111611;
        --bg-card: #161c16;
        --border: #1f2a1f;
        --border-bright: #2a3a2a;
        --accent: #00ff88;
        --accent-dim: #00cc6a;
        --accent-glow: rgba(0, 255, 136, 0.15);
        --text: #d4e8d4;
        --text-dim: #6a7a6a;
        --text-bright: #ffffff;
        --danger: #ff4757;
        --warning: #ffa502;
        --mono: 'JetBrains Mono', monospace;
        --sans: 'Space Grotesk', sans-serif;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
        background: var(--bg);
        color: var(--text);
        font-family: var(--sans);
        min-height: 100vh;
        background-image: 
            radial-gradient(circle at 20% 0%, var(--accent-glow) 0%, transparent 50%),
            radial-gradient(circle at 80% 100%, rgba(0, 255, 136, 0.08) 0%, transparent 50%);
        position: relative;
        overflow-x: hidden;
    }

    body::before {
        content: '';
        position: fixed;
        inset: 0;
        background-image: 
            linear-gradient(rgba(0, 255, 136, 0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 136, 0.03) 1px, transparent 1px);
        background-size: 50px 50px;
        pointer-events: none;
        z-index: 0;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 40px 24px;
        position: relative;
        z-index: 1;
    }

    /* Header */
    .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 40px;
        padding-bottom: 24px;
        border-bottom: 1px solid var(--border);
    }

    .logo {
        display: flex;
        align-items: center;
        gap: 16px;
    }

    .logo-icon {
        width: 48px;
        height: 48px;
        background: var(--accent);
        color: var(--bg);
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: var(--mono);
        font-weight: 800;
        font-size: 20px;
        border-radius: 4px;
        position: relative;
        box-shadow: 0 0 30px var(--accent-glow);
    }

    .logo-icon::after {
        content: '';
        position: absolute;
        inset: -4px;
        border: 1px solid var(--accent);
        border-radius: 6px;
        opacity: 0.3;
    }

    .logo-text h1 {
        font-family: var(--mono);
        font-size: 22px;
        font-weight: 700;
        color: var(--text-bright);
        letter-spacing: -0.5px;
    }

    .logo-text p {
        font-family: var(--mono);
        font-size: 11px;
        color: var(--text-dim);
        text-transform: uppercase;
        letter-spacing: 2px;
        margin-top: 2px;
    }

    .status-badge {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 16px;
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 4px;
        font-family: var(--mono);
        font-size: 12px;
    }

    .status-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--text-dim);
        position: relative;
    }

    .status-dot.online {
        background: var(--accent);
        box-shadow: 0 0 10px var(--accent);
    }

    .status-dot.online::before {
        content: '';
        position: absolute;
        inset: -4px;
        border-radius: 50%;
        background: var(--accent);
        opacity: 0.3;
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 0.3; }
        50% { transform: scale(1.5); opacity: 0; }
    }

    /* Login Screen */
    .login-screen {
        max-width: 420px;
        margin: 100px auto;
        padding: 40px;
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 8px;
        position: relative;
    }

    .login-screen::before {
        content: '';
        position: absolute;
        top: -1px;
        left: 20px;
        right: 20px;
        height: 1px;
        background: linear-gradient(90deg, transparent, var(--accent), transparent);
    }

    .login-screen h2 {
        font-family: var(--mono);
        font-size: 18px;
        color: var(--text-bright);
        margin-bottom: 8px;
    }

    .login-screen p {
        font-size: 13px;
        color: var(--text-dim);
        margin-bottom: 24px;
    }

    /* Grid Layout */
    .main-grid {
        display: grid;
        grid-template-columns: 1fr 380px;
        gap: 24px;
    }

    @media (max-width: 900px) {
        .main-grid {
            grid-template-columns: 1fr;
        }
    }

    /* Card */
    .card {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 8px;
        padding: 24px;
        margin-bottom: 24px;
        position: relative;
    }

    .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 20px;
        padding-bottom: 16px;
        border-bottom: 1px solid var(--border);
    }

    .card-title {
        font-family: var(--mono);
        font-size: 13px;
        font-weight: 600;
        color: var(--text-bright);
        text-transform: uppercase;
        letter-spacing: 1.5px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .card-title::before {
        content: '▸';
        color: var(--accent);
    }

    /* Tabs */
    .tabs {
        display: flex;
        gap: 4px;
        margin-bottom: 24px;
        padding: 4px;
        background: var(--bg-elevated);
        border: 1px solid var(--border);
        border-radius: 6px;
    }

    .tab {
        flex: 1;
        padding: 10px 16px;
        background: transparent;
        border: none;
        color: var(--text-dim);
        font-family: var(--mono);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        border-radius: 4px;
        transition: all 0.2s;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .tab:hover {
        color: var(--text);
    }

    .tab.active {
        background: var(--accent);
        color: var(--bg);
        font-weight: 600;
    }

    .tab-content {
        display: none;
    }

    .tab-content.active {
        display: block;
        animation: fadeIn 0.3s;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Form */
    .form-group {
        margin-bottom: 18px;
    }

    .form-label {
        display: block;
        font-family: var(--mono);
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: var(--text-dim);
        margin-bottom: 8px;
    }

    .form-input,
    .form-textarea {
        width: 100%;
        background: var(--bg-elevated);
        border: 1px solid var(--border);
        border-radius: 4px;
        padding: 12px 14px;
        color: var(--text-bright);
        font-family: var(--mono);
        font-size: 14px;
        transition: all 0.2s;
        resize: vertical;
    }

    .form-input:focus,
    .form-textarea:focus {
        outline: none;
        border-color: var(--accent);
        background: var(--bg);
        box-shadow: 0 0 0 3px var(--accent-glow);
    }

    .form-textarea {
        min-height: 120px;
        font-family: var(--sans);
        line-height: 1.5;
    }

    .char-counter {
        display: flex;
        justify-content: space-between;
        margin-top: 6px;
        font-family: var(--mono);
        font-size: 11px;
        color: var(--text-dim);
    }

    /* Buttons */
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        background: var(--accent);
        color: var(--bg);
        border: none;
        border-radius: 4px;
        font-family: var(--mono);
        font-size: 13px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        cursor: pointer;
        transition: all 0.2s;
        position: relative;
        overflow: hidden;
    }

    .btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 20px var(--accent-glow);
    }

    .btn:active {
        transform: translateY(0);
    }

    .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none;
    }

    .btn-ghost {
        background: transparent;
        color: var(--text);
        border: 1px solid var(--border-bright);
    }

    .btn-ghost:hover {
        background: var(--bg-elevated);
        border-color: var(--accent);
        color: var(--accent);
        box-shadow: none;
    }

    .btn-danger {
        background: var(--danger);
        color: white;
    }

    .btn-block {
        width: 100%;
        justify-content: center;
    }

    /* Connection Panel */
    .connection-info {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-bottom: 20px;
    }

    .info-item {
        padding: 12px;
        background: var(--bg-elevated);
        border: 1px solid var(--border);
        border-radius: 4px;
    }

    .info-item-label {
        font-family: var(--mono);
        font-size: 10px;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: var(--text-dim);
        margin-bottom: 4px;
    }

    .info-item-value {
        font-family: var(--mono);
        font-size: 14px;
        color: var(--text-bright);
        font-weight: 500;
    }

    /* Console / Logs */
    .console {
        background: #050805;
        border: 1px solid var(--border);
        border-radius: 4px;
        padding: 16px;
        font-family: var(--mono);
        font-size: 12px;
        line-height: 1.6;
        max-height: 320px;
        overflow-y: auto;
    }

    .console::-webkit-scrollbar {
        width: 8px;
    }

    .console::-webkit-scrollbar-track {
        background: var(--bg-elevated);
    }

    .console::-webkit-scrollbar-thumb {
        background: var(--border-bright);
        border-radius: 4px;
    }

    .console-line {
        color: var(--text);
        padding: 2px 0;
    }

    .console-line.success { color: var(--accent); }
    .console-line.error { color: var(--danger); }
    .console-line.warning { color: var(--warning); }
    .console-line.info { color: #5db4ff; }

    .console-empty {
        color: var(--text-dim);
        font-style: italic;
    }

    /* Toast notifications */
    .toast-container {
        position: fixed;
        top: 24px;
        right: 24px;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .toast {
        padding: 14px 20px;
        background: var(--bg-card);
        border: 1px solid var(--border-bright);
        border-radius: 4px;
        font-family: var(--mono);
        font-size: 13px;
        min-width: 280px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        animation: slideIn 0.3s;
        border-left: 3px solid var(--accent);
    }

    .toast.error {
        border-left-color: var(--danger);
    }

    .toast.warning {
        border-left-color: var(--warning);
    }

    @keyframes slideIn {
        from { transform: translateX(120%); }
        to { transform: translateX(0); }
    }

    /* Hidden */
    .hidden {
        display: none !important;
    }

    /* Loader */
    .loader {
        display: inline-block;
        width: 14px;
        height: 14px;
        border: 2px solid currentColor;
        border-top-color: transparent;
        border-radius: 50%;
        animation: spin 0.6s linear infinite;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    /* Footer */
    .footer {
        margin-top: 60px;
        padding-top: 24px;
        border-top: 1px solid var(--border);
        text-align: center;
        font-family: var(--mono);
        font-size: 11px;
        color: var(--text-dim);
        letter-spacing: 1px;
    }
</style>
</head>
<body>

<div class="toast-container" id="toastContainer"></div>

<div class="container">

    <!-- LOGIN -->
    <div id="loginScreen" class="login-screen <?= isset($_SESSION['authenticated']) && $_SESSION['authenticated'] ? 'hidden' : '' ?>">
        <div class="logo" style="margin-bottom: 24px;">
            <div class="logo-icon">$</div>
            <div class="logo-text">
                <h1>SMS GATEWAY</h1>
                <p>ADB Control Panel</p>
            </div>
        </div>
        <h2>// Avtorizatsiya</h2>
        <p>Tizimga kirish uchun parol kiriting</p>
        <form id="loginForm">
            <div class="form-group">
                <label class="form-label">Parol</label>
                <input type="password" class="form-input" id="passwordInput" placeholder="••••••••••" autofocus>
            </div>
            <button type="submit" class="btn btn-block">
                <span>Kirish</span>
                <span>→</span>
            </button>
        </form>
    </div>

    <!-- MAIN APP -->
    <div id="mainApp" class="<?= !(isset($_SESSION['authenticated']) && $_SESSION['authenticated']) ? 'hidden' : '' ?>">
        
        <header class="header">
            <div class="logo">
                <div class="logo-icon">$</div>
                <div class="logo-text">
                    <h1>SMS GATEWAY</h1>
                    <p>ADB · WiFi · v1.0</p>
                </div>
            </div>
            <div style="display: flex; gap: 12px; align-items: center;">
                <div class="status-badge">
                    <span class="status-dot" id="statusDot"></span>
                    <span id="statusText">Tekshirilmoqda...</span>
                </div>
                <button class="btn btn-ghost" id="logoutBtn">Chiqish</button>
            </div>
        </header>

        <div class="main-grid">
            <!-- LEFT COLUMN -->
            <div>
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">SMS Yuborish</div>
                    </div>

                    <div class="tabs">
                        <button class="tab active" data-tab="single">Bitta raqam</button>
                        <button class="tab" data-tab="bulk">Ommaviy</button>
                    </div>

                    <!-- Single SMS -->
                    <div class="tab-content active" id="tab-single">
                        <div class="form-group">
                            <label class="form-label">Telefon raqami</label>
                            <input type="text" class="form-input" id="singlePhone" placeholder="+998901234567">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Xabar matni</label>
                            <textarea class="form-textarea" id="singleMessage" maxlength="500" placeholder="Xabaringizni yozing..."></textarea>
                            <div class="char-counter">
                                <span>0 / 500 belgi</span>
                                <span id="smsCount">1 SMS</span>
                            </div>
                        </div>
                        <button class="btn btn-block" id="sendSingleBtn">
                            <span>SMS Yuborish</span>
                            <span>→</span>
                        </button>
                    </div>

                    <!-- Bulk SMS -->
                    <div class="tab-content" id="tab-bulk">
                        <div class="form-group">
                            <label class="form-label">Telefon raqamlari (har biri yangi qatorga yoki vergul bilan)</label>
                            <textarea class="form-textarea" id="bulkPhones" placeholder="+998901234567&#10;+998907654321&#10;+998935554433" style="min-height: 100px;"></textarea>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Bir xil xabar matni</label>
                            <textarea class="form-textarea" id="bulkMessage" maxlength="500" placeholder="Hammaga yuboriladigan xabar..."></textarea>
                        </div>
                        <button class="btn btn-block" id="sendBulkBtn">
                            <span>Ommaviy yuborish</span>
                            <span>→</span>
                        </button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Konsol / Loglar</div>
                        <button class="btn btn-ghost" id="refreshLogsBtn" style="padding: 6px 12px; font-size: 11px;">↻ Yangilash</button>
                    </div>
                    <div class="console" id="console">
                        <div class="console-line console-empty">// Loglar bu yerda paydo bo'ladi...</div>
                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN -->
            <div>
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Ulanish</div>
                    </div>

                    <div class="connection-info">
                        <div class="info-item">
                            <div class="info-item-label">IP manzil</div>
                            <div class="info-item-value">192.168.1.100</div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Port</div>
                            <div class="info-item-value">5555</div>
                        </div>
                    </div>

                    <button class="btn btn-block" id="connectBtn" style="margin-bottom: 8px;">
                        <span>Ulanish</span>
                    </button>
                    <button class="btn btn-block btn-ghost" id="disconnectBtn">
                        <span>Uzish</span>
                    </button>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Qurilmalar</div>
                    </div>
                    <div id="devicesList">
                        <div class="console-line console-empty" style="font-family: var(--mono); font-size: 12px;">// Qurilmalar topilmadi</div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="card-title">Yo'riqnoma</div>
                    </div>
                    <div style="font-size: 13px; line-height: 1.7; color: var(--text);">
                        <p style="margin-bottom: 12px;"><strong style="color: var(--accent); font-family: var(--mono);">01.</strong> Telefon va kompyuter <em>bitta WiFi</em>ga ulangan bo'lsin</p>
                        <p style="margin-bottom: 12px;"><strong style="color: var(--accent); font-family: var(--mono);">02.</strong> Telefonda <em>Developer options</em> yoqilgan bo'lsin</p>
                        <p style="margin-bottom: 12px;"><strong style="color: var(--accent); font-family: var(--mono);">03.</strong> <em>Wireless debugging</em> yoki <em>ADB over network</em> yoqilsin</p>
                        <p><strong style="color: var(--accent); font-family: var(--mono);">04.</strong> "Ulanish" tugmasini bosing</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            SMS GATEWAY · ADB OVER WIFI · BUILT WITH PHP
        </div>
    </div>
</div>

<script>
// =================================================================
// SMS GATEWAY - Frontend Logic
// =================================================================

const API = 'api.php';

// Helpers
function $(id) { return document.getElementById(id); }

async function apiCall(action, data = {}) {
    const formData = new FormData();
    formData.append('action', action);
    for (const [k, v] of Object.entries(data)) {
        formData.append(k, v);
    }
    
    try {
        const res = await fetch(API, { method: 'POST', body: formData });
        return await res.json();
    } catch (e) {
        return { ok: false, message: 'Tarmoq xatosi: ' + e.message };
    }
}

function toast(message, type = 'success') {
    const container = $('toastContainer');
    const el = document.createElement('div');
    el.className = 'toast ' + (type === 'error' ? 'error' : type === 'warning' ? 'warning' : '');
    el.textContent = message;
    container.appendChild(el);
    setTimeout(() => {
        el.style.opacity = '0';
        el.style.transform = 'translateX(120%)';
        el.style.transition = 'all 0.3s';
        setTimeout(() => el.remove(), 300);
    }, 4000);
}

function logToConsole(message, type = 'info') {
    const console = $('console');
    const empty = console.querySelector('.console-empty');
    if (empty) empty.remove();
    
    const line = document.createElement('div');
    line.className = 'console-line ' + type;
    const time = new Date().toLocaleTimeString();
    line.textContent = `[${time}] ${message}`;
    console.insertBefore(line, console.firstChild);
}

// =================================================================
// LOGIN
// =================================================================
$('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const password = $('passwordInput').value;
    if (!password) return toast('Parol kiriting', 'error');
    
    const res = await apiCall('login', { password });
    if (res.ok) {
        $('loginScreen').classList.add('hidden');
        $('mainApp').classList.remove('hidden');
        toast('Muvaffaqiyatli kirildi');
        checkStatus();
    } else {
        toast(res.message || 'Xato parol', 'error');
    }
});

// LOGOUT
$('logoutBtn')?.addEventListener('click', async () => {
    await apiCall('logout');
    location.reload();
});

// =================================================================
// TABS
// =================================================================
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        $('tab-' + tab.dataset.tab).classList.add('active');
    });
});

// =================================================================
// CHAR COUNTER
// =================================================================
$('singleMessage')?.addEventListener('input', (e) => {
    const len = e.target.value.length;
    const smsCount = Math.ceil(len / 160) || 1;
    const counter = e.target.parentNode.querySelector('.char-counter');
    counter.children[0].textContent = `${len} / 500 belgi`;
    counter.children[1].textContent = `${smsCount} SMS`;
});

// =================================================================
// CONNECTION
// =================================================================
$('connectBtn')?.addEventListener('click', async (e) => {
    const btn = e.target.closest('button');
    btn.disabled = true;
    btn.innerHTML = '<span class="loader"></span><span>Ulanmoqda...</span>';
    
    logToConsole('ADB ulanish boshlandi...', 'info');
    const res = await apiCall('connect');
    
    if (res.ok) {
        toast('Telefonga ulandi');
        logToConsole(res.message, 'success');
    } else {
        toast('Ulanib bo\'lmadi: ' + res.message, 'error');
        logToConsole('Xato: ' + res.message, 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<span>Ulanish</span>';
    checkStatus();
});

$('disconnectBtn')?.addEventListener('click', async () => {
    const res = await apiCall('disconnect');
    logToConsole('Ulanish uzildi', 'warning');
    toast(res.ok ? 'Uzildi' : 'Xato', res.ok ? 'success' : 'error');
    checkStatus();
});

// =================================================================
// SINGLE SMS
// =================================================================
$('sendSingleBtn')?.addEventListener('click', async (e) => {
    const phone = $('singlePhone').value.trim();
    const message = $('singleMessage').value.trim();
    
    if (!phone || !message) {
        return toast('Raqam va xabar majburiy', 'error');
    }
    
    const btn = e.target.closest('button');
    btn.disabled = true;
    btn.innerHTML = '<span class="loader"></span><span>Yuborilmoqda...</span>';
    
    logToConsole(`SMS yuborish: ${phone}`, 'info');
    const res = await apiCall('send', { phone, message });
    
    if (res.ok) {
        toast(res.message);
        logToConsole(`✓ Yuborildi: ${phone}`, 'success');
        $('singlePhone').value = '';
        $('singleMessage').value = '';
        $('singleMessage').dispatchEvent(new Event('input'));
    } else {
        toast('Xato: ' + res.message, 'error');
        logToConsole(`✗ Xato: ${res.message}`, 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<span>SMS Yuborish</span><span>→</span>';
});

// =================================================================
// BULK SMS
// =================================================================
$('sendBulkBtn')?.addEventListener('click', async (e) => {
    const phones = $('bulkPhones').value.trim();
    const message = $('bulkMessage').value.trim();
    
    if (!phones || !message) {
        return toast('Raqamlar va xabar majburiy', 'error');
    }
    
    const count = phones.split(/[\s,;]+/).filter(p => p).length;
    if (!confirm(`${count} ta raqamga SMS yuborilsinmi?`)) return;
    
    const btn = e.target.closest('button');
    btn.disabled = true;
    btn.innerHTML = '<span class="loader"></span><span>Yuborilmoqda...</span>';
    
    logToConsole(`Ommaviy SMS: ${count} ta raqam`, 'info');
    const res = await apiCall('send_bulk', { phones, message });
    
    if (res.ok) {
        toast(`${res.success}/${res.total} SMS yuborildi`, res.failed > 0 ? 'warning' : 'success');
        logToConsole(`✓ Ommaviy yakunlandi: ${res.success} muvaffaqiyatli, ${res.failed} xato`, 'success');
    } else {
        toast('Xato: ' + res.message, 'error');
        logToConsole(`✗ Xato: ${res.message}`, 'error');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<span>Ommaviy yuborish</span><span>→</span>';
});

// =================================================================
// STATUS CHECK
// =================================================================
async function checkStatus() {
    const res = await apiCall('status');
    const dot = $('statusDot');
    const text = $('statusText');
    
    if (res.ok && res.connected) {
        dot.classList.add('online');
        text.textContent = 'ULANGAN';
    } else {
        dot.classList.remove('online');
        text.textContent = 'ULANMAGAN';
    }
    
    // Devices list
    const devicesList = $('devicesList');
    if (res.devices && res.devices.length > 0) {
        devicesList.innerHTML = res.devices.map(d => `
            <div style="padding: 10px 12px; background: var(--bg-elevated); border: 1px solid var(--border); border-radius: 4px; margin-bottom: 8px; font-family: var(--mono); font-size: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="color: var(--text-bright);">${d.id}</span>
                    <span style="color: ${d.status === 'device' ? 'var(--accent)' : 'var(--warning)'}; font-size: 10px; text-transform: uppercase;">${d.status}</span>
                </div>
            </div>
        `).join('');
    } else {
        devicesList.innerHTML = '<div class="console-line console-empty" style="font-family: var(--mono); font-size: 12px;">// Qurilmalar topilmadi</div>';
    }
}

// =================================================================
// LOGS
// =================================================================
$('refreshLogsBtn')?.addEventListener('click', async () => {
    const res = await apiCall('logs');
    const console = $('console');
    console.innerHTML = '';
    
    if (res.logs && res.logs.length > 0) {
        res.logs.forEach(line => {
            const div = document.createElement('div');
            div.className = 'console-line';
            if (line.includes('xato') || line.includes('Xato')) div.classList.add('error');
            else if (line.includes('yuborildi')) div.classList.add('success');
            else div.classList.add('info');
            div.textContent = line;
            console.appendChild(div);
        });
    } else {
        console.innerHTML = '<div class="console-line console-empty">// Loglar topilmadi</div>';
    }
});

// Auto status check
if (!$('mainApp').classList.contains('hidden')) {
    checkStatus();
    setInterval(checkStatus, 15000);
}
</script>

</body>
</html>
